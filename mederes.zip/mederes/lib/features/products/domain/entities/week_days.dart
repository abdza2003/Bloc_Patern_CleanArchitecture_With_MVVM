import 'package:school_cafteria/features/products/data/models/school_days_model.dart';

class WeekDays {
  List<SchoolDaysModel>? days;
  dynamic weeklyBalance;
  dynamic weeklyProductsPrice;

  WeekDays({this.days, this.weeklyBalance, this.weeklyProductsPrice});
}

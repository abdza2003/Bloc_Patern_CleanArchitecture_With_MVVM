import 'package:school_cafteria/core/util/hex_color.dart';
import 'package:flutter/material.dart';

class ColorManager {
  static Color primary = HexColor('#51093C');
}
